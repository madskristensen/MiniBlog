﻿// MasterHelper.cs
// © 2009 Chris Hynes
// You may use this code under the Creative Commons Attribution-ShareAlike license.
// http://creativecommons.org/licenses/by-sa/3.0/us/

using System;
using System.Collections;
using System.Reflection;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Krystalware.Web
{
    public static class MasterHelper
    {
        static readonly Type _masterType = typeof(MasterPage);
        static readonly PropertyInfo _contentTemplatesProp = _masterType.GetProperty("ContentTemplates", BindingFlags.GetProperty | BindingFlags.NonPublic | BindingFlags.Instance);

        public static bool HasContentOrControls(ContentPlaceHolder cph)
        {
            return HasNonEmptyControls(cph) || HasContentPageContent(cph);
        }

        public static bool HasContentPageContent(ContentPlaceHolder cph)
        {
            IDictionary templates = null;
            MasterPage master = cph.Page.Master;

            while (templates == null && master != null)
            {
                templates = (IDictionary)_contentTemplatesProp.GetValue(master, null);
                master = master.Master;
            }

            if (templates == null)
                return false;

            bool isSpecified = false;

            foreach (string key in templates.Keys)
            {
                if (key == cph.ID)
                {
                    isSpecified = true;

                    break;
                }
            }

            return isSpecified;
        }

        public static bool HasNonEmptyControls(ContentPlaceHolder cph)
        {
            if (cph.Controls.Count == 0)
            {
                return false;
            }
            else if (cph.Controls.Count == 1)
            {
                LiteralControl c = cph.Controls[0] as LiteralControl;

                if (string.IsNullOrEmpty(c.Text) || IsWhiteSpace(c.Text))
                    return false;
            }

            return true;
        }

        static bool IsWhiteSpace(string s)
        {
            for (int i = 0; i < s.Length; i++)
                if (!char.IsWhiteSpace(s[i]))
                    return false;

            return true;
        }
    }
}

﻿// MasterHelperExtensions.cs
// © 2009 Chris Hynes
// You may use this code under the Creative Commons Attribution-ShareAlike license.
// http://creativecommons.org/licenses/by-sa/3.0/us/

using System;
using System.Web.UI.WebControls;

namespace Krystalware.Web
{
    public static class MasterHelperExtensions
    {
        public static bool HasContentOrControls(this ContentPlaceHolder cph)
        {
            return MasterHelper.HasContentOrControls(cph);
        }
    }
}

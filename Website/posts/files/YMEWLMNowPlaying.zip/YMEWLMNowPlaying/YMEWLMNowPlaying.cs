// YMEWLMNowPlaying.cs
// Copyright � 2006 Chris Hynes. All Rights Reserved.
//
// You may use this file as you like, as long as this notice remains intact and attribution is observed.

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;

using Microsoft.Win32;

using Yahoo.MusicEngine;
using Yahoo.MusicEngine.Interop;
using Yahoo.MusicEngine.Interop.Plugin;
using Yahoo.MusicEngine.Interop.MediaPlayer;

namespace YMEWLMNowPlaying
{
    public class YMEWLMNowPlaying : IRMPPlugin
    {
        IRMPMediaPlayer _mediaPlayer = null;
        RMPPlaylistEngine _playlistEngine;

        string IRMPPlugin.Name
        {
            get { return "WLM Now Playing"; }
        }

        string IRMPPlugin.Description
        {
            get { return "Now playing information for Windows Live Messenger."; }
        }

        void IRMPPlugin.Initialize(object mediaPlayer)
        {
            try
            {
                _mediaPlayer = (IRMPMediaPlayer)mediaPlayer;
                _playlistEngine = (RMPPlaylistEngine)_mediaPlayer.PlaylistEngine;

                _playlistEngine.OnPlayTrack += new DPlaylistEngineEvents_OnPlayTrackEventHandler(_playlistEngine_OnPlayTrack);
            }
            catch (Exception e)
            {
                //_mediaPlayer.MsgBox("IRMPPlugin.Initialize: Exception - " + e.ToString(), "YMEWLMNowPlaying", 0);
            }
        }

        private void _playlistEngine_OnPlayTrack(Object RMPMediaObject, int indexToBePlayed)
        {
            Yahoo.MusicEngine.Interop.MediaPlayer.RMPMediaObject mediaObject;
            Yahoo.MusicEngine.Interop.MediaPlayer.RMPMetadata metaData;

            try
            {
                if (indexToBePlayed < 0)
                {
                    WLMController.HideWLMNowPlaying();
                }
                else
                {
                    mediaObject = (Yahoo.MusicEngine.Interop.MediaPlayer.RMPMediaObject)RMPMediaObject;
                    metaData = (Yahoo.MusicEngine.Interop.MediaPlayer.RMPMetadata)mediaObject.Metadata;

                    string artist = metaData.GetPredefinedValue(PredefinedMetadataField.METADATA_ARTIST);
                    string album = metaData.GetPredefinedValue(PredefinedMetadataField.METADATA_ALBUM);
                    string title = metaData.GetPredefinedValue(PredefinedMetadataField.METADATA_TITLE);

                    WLMController.SetWLMNowPlaying(title, artist, album);
                }
            }
            catch (COMException exc)
            {
                //MessageBox.Show("ERROR: " + Console.Error.NewLine + exc.ToString() + Console.Error.NewLine);
            }
        }

        bool IRMPPlugin.SafeToShutdown
        {
            get { return true; }
        }

        string IRMPPlugin.SafeToShutdownReason
        {
            get { return ""; }
        }

        void IRMPPlugin.Shutdown()
        {
        }

        void IRMPPlugin.UICommand(
            UICommandID command,
            string mode,
            string data)
        {
        }

        [ComRegisterFunction]
        static void ComRegister(Type t)
        {
            AssemblyDescriptionAttribute assemblyDescAttr = (AssemblyDescriptionAttribute)Assembly.GetAssembly(t).GetCustomAttributes(typeof(AssemblyDescriptionAttribute), true)[0];

            string description = "YMEWLMNowPlaying description";
            
            if (assemblyDescAttr != null)
                description = assemblyDescAttr.ToString();

            string keyName = @"Software\Yahoo\YMP\Plugins";
            RegistryKey key = Registry.LocalMachine.OpenSubKey(keyName, true);

            if (key != null)
            {
                keyName = "YMEWLMNowPlaying.YMEWLMNowPlaying";
                key = key.CreateSubKey(keyName);

                key.SetValue("Name", "YMEWLMNowPlaying");
                key.SetValue("Description", description);
                key.SetValue("Enabled", 1);
            }
        }

        [ComUnregisterFunction]
        static void ComUnregister(Type t)
        {
            string keyName = @"Software\Yahoo\YMP\Plugins\YMEWLMNowPlaying.YMEWLMNowPlaying";

            Registry.LocalMachine.DeleteSubKeyTree(keyName);
        }
    }
}

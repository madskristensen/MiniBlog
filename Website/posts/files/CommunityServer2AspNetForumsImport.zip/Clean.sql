/*
   Copyright � 2008 Chris Hynes. All Rights Reserved.

   http://programcsharp.com
   http://krystalware.com

   This work is licensed under a Creative Commons Attribution-Share Alike 3.0 United States License.

   http://creativecommons.org/licenses/by-sa/3.0/us/
*/

-- THE FOLLOWING STATEMENTS TRUNCATE AND CLEAR THE CURRENT DATABASE.
-- MAKE SURE YOU WANT TO DO THIS BEFORE RUNNING.
-- Uncomment and run the lines below to totally clear all the ASP.NET membership, users, and
-- aspnetforums users, forums, messages etc. in the current database.
/* TRUNCATE TABLE aspnet_Membership
DELETE FROM aspnet_Users
DELETE FROM aspnet_Applications
TRUNCATE TABLE ForumUsers
TRUNCATE TABLE ForumGroups
TRUNCATE TABLE Forums
TRUNCATE TABLE ForumTopics
TRUNCATE TABLE ForumMessages */
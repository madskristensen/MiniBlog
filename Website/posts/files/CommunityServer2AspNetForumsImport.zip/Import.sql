/*
   Copyright � 2008 Chris Hynes. All Rights Reserved.

   http://programcsharp.com
   http://krystalware.com

   This work is licensed under a Creative Commons Attribution-Share Alike 3.0 United States License.

   http://creativecommons.org/licenses/by-sa/3.0/us/
*/

-- BEFORE YOU DO ANYTHING ELSE, EXECUTE A SEARCH AND REPLACE ON THIS FILE TO CHANGE
-- "CSDatabaseName" TO THE NAME OF YOUR COMMUNITY SERVER DATABASE.

-- Defines the ASP.NET ApplicationId GUID from which to import users
DECLARE @applicationId uniqueidentifier
SET @applicationId = 'f30a4659-f071-4eb3-8920-23052ec7993e'

-- Defines the Community Server group id from which to import forums
DECLARE @groupId int
SET @groupId=27

-- ASP.NET membership
INSERT INTO aspnet_Applications SELECT * FROM CSDatabaseName.dbo.aspnet_Applications WHERE ApplicationId=@applicationId
INSERT INTO aspnet_Users SELECT * FROM CSDatabaseName.dbo.aspnet_Users WHERE ApplicationId=@applicationId
INSERT INTO aspnet_Membership
(
	ApplicationId,
	UserId,
	Password,
	PasswordFormat,
	PasswordSalt,
	MobilePIN,
	Email,
	LoweredEmail,
	PasswordQuestion,
	PasswordAnswer,
	IsApproved,
	IsLockedOut,
	CreateDate,
	LastLoginDate,
	LastPasswordChangedDate,
	LastLockoutDate,
	FailedPasswordAttemptCount,
	FailedPasswordAttemptWindowStart,
	FailedPasswordAnswerAttemptCount,
	FailedPasswordAnswerAttemptWindowStart,
	Comment
)
SELECT
	ApplicationId,
	UserId,
	Password,
	PasswordFormat,
	PasswordSalt,
	MobilePIN,
	Email,
	LoweredEmail,
	PasswordQuestion,
	PasswordAnswer,
	IsApproved,
	IsLockedOut,
	CreateDate,
	LastLoginDate,
	LastPasswordChangedDate,
	LastLockoutDate,
	FailedPasswordAttemptCount,
	FailedPasswordAttemptWindowStart,
	FailedPasswordAnswerAttemptCount,
	FailedPasswordAnswerAttemptWindowStart,
	Comment
FROM CSDatabaseName.dbo.aspnet_Membership WHERE ApplicationId=@applicationId

-- Forum users
SET IDENTITY_INSERT ForumUsers ON
INSERT INTO ForumUsers
	(
		UserId,
		UserName,
		Email,
		[Password],
		Homepage,
		Interests,
		RegistrationDate,
		Disabled,
		ActivationCode,
		PostsCount
	)
SELECT
	cs_Users.UserId,
	UserName,
	Coalesce(Email, '') AS Email,
	'none' as Password,
	'' as Homepage,
	'' as Interests,
	CreateDate as RegistrationDate,
	IsLockedOut,
	'' as ActivationCode,
	TotalPosts
FROM
	aspnet_Users
		INNER JOIN aspnet_Membership ON aspnet_Users.UserId=aspnet_Membership.UserId
		INNER JOIN CSDatabaseName.dbo.cs_Users cs_Users ON aspnet_Users.UserId=cs_Users.MembershipId
		INNER JOIN CSDatabaseName.dbo.cs_UserProfile cs_UserProfile ON cs_Users.UserId=cs_UserProfile.UserId AND cs_UserProfile.MembershipId=aspnet_Membership.UserId
SET IDENTITY_INSERT ForumUsers OFF

-- Forum Groups
SET IDENTITY_INSERT ForumGroups ON
INSERT INTO ForumGroups
(
	GroupId,
	GroupName
)
SELECT
	GroupId,
	Name
FROM
	CSDatabaseName.dbo.cs_Groups
WHERE
	GroupId=@groupId
SET IDENTITY_INSERT ForumGroups OFF

-- Forums
SET IDENTITY_INSERT Forums ON
INSERT INTO Forums
(
	ForumId,
	Title,
	Description,
	Premoderated,
	GroupId
)
SELECT
	SectionId AS ForumId,
	Name AS Title,
	Description,
	IsModerated AS Premoderated,
	GroupId
FROM
	CSDatabaseName.dbo.cs_Sections
WHERE
	GroupId IN (SELECT GroupId FROM ForumGroups)
SET IDENTITY_INSERT Forums OFF

-- Topics
SET IDENTITY_INSERT ForumTopics ON
INSERT INTO ForumTopics
(
	TopicId,
	ForumId,
	UserId,
	Subject,
	Visible,
	LastMessageId,
	IsSticky,
	IsClosed,
	ViewsCount
)
SELECT
	ThreadId AS TopicId,
	SectionId AS ForumId,
	UserId,
	(SELECT TOP 1 Subject FROM CSDatabaseName.dbo.cs_Posts WHERE ThreadId=th.ThreadId ORDER BY PostId ASC),
	MostRecentPostId,
	IsApproved AS Visible,
	IsSticky,
	IsLocked AS IsClosed,
	TotalViews AS ViewsCount
FROM
	CSDatabaseName.dbo.cs_Threads th
WHERE
	SectionID IN (SELECT ForumId FROM Forums)
SET IDENTITY_INSERT ForumTopics OFF

-- Posts
SET IDENTITY_INSERT ForumMessages ON
INSERT INTO ForumMessages
(
	MessageId,
	TopicId,
	UserId,
	Body,
	CreationDate,
	Visible
)
SELECT
	PostId,
	ThreadId,
	UserId,
	FormattedBody,
	PostDate,
	IsApproved
FROM
	CSDatabaseName.dbo.cs_Posts WHERE ThreadId IN (SELECT TopicId FROM ForumTopics)
SET IDENTITY_INSERT ForumMessages OFF

-- Tracked Threads
INSERT INTO ForumSubscriptions
(
	TopicId,
	UserId
)
SELECT
	ThreadId,
	UserId
FROM
	CSDatabaseName.dbo.cs_TrackedThreads WHERE ThreadId IN (SELECT TopicId FROM ForumTopics)

-- Tracked Forums
INSERT INTO ForumNewTopicSubscriptions
(
	ForumId,
	UserId
)
SELECT
	SectionId,
	UserId
FROM
	CSDatabaseName.dbo.cs_TrackedSections WHERE SectionId IN (SELECT ForumId FROM Forums)

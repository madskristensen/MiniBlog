// Image2Png.cs
// � 2006 Chris Hynes
// You may use this code under the Creative Commons Attribution-ShareAlike license.
// http://creativecommons.org/licenses/by-sa/2.5/

using System;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using Krystalware.Utilities;

namespace Krystalware
{
	public class Image2Png
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		static void Main(string[] args) 
		{
			if (args.Length > 0)
			{
				string srcFileName = args[0];

                using (Stream s = File.OpenRead(srcFileName))
                using (Bitmap src = Image.FromStream(s, false, false) as Bitmap)
                {
                    string pngFileName = Path.Combine(Path.GetDirectoryName(srcFileName), Path.GetFileNameWithoutExtension(srcFileName) + ".png");

                    src.MakeTransparent(TransparentColor);

                    src.Save(pngFileName, ImageFormat.Png);
                }
            }
			else
			{
                RegistryHelper.RegisterHandler(".bmp", "bmp2png", "Convert To Png", true);

                MessageBox.Show("Bmp2Png extension registered successfully.", "Registration", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
		}

        static Color TransparentColor
        {
            get
            {
                string transparentColor = ConfigurationManager.AppSettings["transparentColor"];

                if (!string.IsNullOrEmpty(transparentColor))
                {
                    try
                    {
                        string[] colorStrings = transparentColor.Split(',');
                        int[] colors = new int[3];

                        for (int i = 0; i < colors.Length; i++)
                            colors[i] = int.Parse(colorStrings[i].Trim());

                        return Color.FromArgb(colors[0], colors[1], colors[2]);
                    }
                    catch
                    { }
                }

                // Couldn't get configuration color. Use default.
                return Color.FromArgb(0, 255, 128);
            }
        }
	}
}
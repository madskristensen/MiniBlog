// RegistryHelper.cs
// � 2006 Chris Hynes
// You may use this code under the Creative Commons Attribution-ShareAlike license.
// http://creativecommons.org/licenses/by-sa/2.5/

using System;
using System.Reflection;
using Microsoft.Win32;

namespace Krystalware.Utilities
{
    public class RegistryHelper
    {
        private RegistryHelper()
        {}

        public static void RegisterHandler(string extension, string commandName, string commandText, bool isSystemwide)
        {
            Assembly a = Assembly.GetEntryAssembly();

            string fileName = a.Location;

            RegisterHandler(extension, fileName, commandName, commandText, isSystemwide);
        }

        public static void RegisterHandler(string extension, string programPath, string commandName, string commandText, bool isSystemWide)
        {
            RegistryKey rootKey = null;

            RegistryKey softwareKey = null;

            RegistryKey extensionKey = null;

            RegistryKey handlerKey = null;
            RegistryKey shellKey = null;
            RegistryKey commandHolderKey = null;
            RegistryKey commandKey = null;

            try
            {
                if (isSystemWide)
                {
                    rootKey = Registry.ClassesRoot;
                }
                else
                {
                    softwareKey = Registry.CurrentUser.OpenSubKey("Software");

                    rootKey = softwareKey.CreateSubKey("Classes");
                }

                // Get the handler associated with the specified extension
                extensionKey = Registry.ClassesRoot.CreateSubKey(extension);

                string handler = extensionKey.GetValue(string.Empty) as string;

                // If there's no handler, create one
                if (handler == null)
                {
                    handler = "Handler" + extension;

                    extensionKey.SetValue(string.Empty, handler);
                }

                // Register this handler
                handlerKey = rootKey.CreateSubKey(handler);

                shellKey = handlerKey.CreateSubKey("shell");
                commandHolderKey = shellKey.CreateSubKey(commandName);
                commandHolderKey.SetValue(string.Empty, commandText);
                commandKey = commandHolderKey.CreateSubKey("command");
                commandKey.SetValue(string.Empty, "\"" + programPath + "\" \"%1\"");
            }
            finally
            {
                if (softwareKey != null)
                    softwareKey.Close();

                if (extensionKey != null)
                    extensionKey.Close();

                if (commandKey != null)
                    commandKey.Close();
                if (commandHolderKey != null)
                    commandHolderKey.Close();
                if (shellKey != null)
                    shellKey.Close();
                if (handlerKey != null)
                    handlerKey.Close();

                if (rootKey != null)
                    rootKey.Close();
            }
        }
    }
}

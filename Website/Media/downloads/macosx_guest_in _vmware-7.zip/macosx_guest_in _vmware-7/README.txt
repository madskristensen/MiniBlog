Introduction
------------
This program allows you to run any flavor of Mac OS X inside a VMware
virtual machine, on any physical machine.

Supported configurations
------------------------
Version 7 of this program is known to work with the following
configurations:

Guest operating system
    Mac OS X (Client or Server) versions: 10.5, 10.6

VMware product
    VMware Workstation (for Windows or Linux) version: 7.1
    VMware Fusion (for Mac OS X) version : 3.1

Hardware
    CPU feature: Intel VT

Instructions for VMware Workstation for Windows
-----------------------------------------------
Install VMware Workstation.

Make sure all virtual machines and VMware Workstation are stopped.

As the Administrator user, run the "windows.bat" program (located in
the same directory as this file) from the command line (Command
Prompt).

Read the "Frequently Asked Questions" section below.

Instructions for VMware Workstation for Linux
---------------------------------------------
Install VMware Workstation.

Make sure all virtual machines and VMware Workstation are stopped.

As the super user, run the "linux" program (located in the same
directory as this file) from the command line.

Read the "Frequently Asked Questions" section below.

Instructions for VMware Fusion for Mac OS X
-------------------------------------------
Install VMware Fusion.

Make sure all virtual machines and VMware Fusion are stopped.

As the super user, run the "macosx" program (located in the same
directory as this file) from the command line (Terminal).

Read the "Frequently Asked Questions" section below.

Frequently Asked Questions
--------------------------
Q1: When I power on a Mac OS X virtual machine, I get the error "Mac
    OS X is not supported with software virtualization".
A1: Mac OS X guest requires that your physical CPU supports Intel
    VT. However that feature is sometimes disabled in the BIOS (this
    is often the case on Dell computers). To enable it, restart your
    physical computer, enter the BIOS setup, enable Intel
    Virtualization Technology, save the new BIOS configuration, and
    then (that is the important part) cold power off the physical
    machine.

Q2: In a virtual machine, the Mac OS X installer does not display any
    volume, so I cannot select one to install Mac OS X on it.
A2: Select "Utilities > Disk Utility" in the menu, select the virtual
    hard disk at the top of the left pane, click on the "Erase" tab at
    the top of the right pane, click on the "Erase" button at the
    bottom of the right pane, and confirm your choice with the "Erase"
    button. Wait until the volume is created, then select
    "Disk Utility > Quit Disk Utility" in the menu. The installer will
    now display the new volume. Select the new volume to install Mac
    OS X on it.

Q3: Can I make the interaction with a Mac OS X virtual machine much
    smoother?
A3: Yes: you need to install "VMware Tools for Mac OS X".
    If you are using VMware Fusion, select your Mac OS X virtual
    machine, then select "Virtual Machine > Install VMware Tools" in
    the menu and follow the instructions.
    If you are using VMware Workstation, then ask a friend who has
    installed the latest version of VMware Fusion to send you the file
    located at
    "/Library/Application Support/VMware Fusion/isoimages/darwin.iso"
    on his physical machine. Using a USB key thumb or networking, copy
    this file inside your Mac OS X virtual machine, and open it.

Motivation
----------
Thanks to the efforts of the OSx86 project (
http://www.osx86project.org/ ), it is now possible to install Mac OS X
on a variety of non-Mac computers.

But this approach:

1) Takes a lot of time and effort for the project developers. They
   must develop driver hacks for a variety of hardware, and they must
   modify their hacks every time Apple breaks them with a minor update
   of Mac OS X.

2) Takes a lot of time and effort for users. They must read the
   project's copious and scattered documentation, and they must
   experiment with many possible solutions, if they want to make Mac
   OS X work nicely on their PCs.

3) Modifies Mac OS X. The Mac OS X bits that users are running on
   their PCs are not the same bits that Apple tested to attest of
   their quality.

Instead, it seems better to stand on the shoulder of giants! It is
already the job of VMware's paid developers to take care of #1 and #3
above by exposing virtual Mac hardware to a Mac OS X guest. Running
Mac OS X inside a VMware virtual machine already is a really good
out-of-the-box experience, and you can bet it will only improve over
time.

Unfortunately, Apple's Mac OS X End-User License Agreements force
VMware into artificially crippling their products:
o You cannot run Mac OS X Client in a virtual machine.
o You cannot run Mac OS X in a virtual machine on a non-Apple physical
  machine.
So all we have to do to solve #2 above is to uncripple VMware's
products! And that is precisely what this program does.

Contact
-------
To provide feedback about this program (for example if it stops
working with later versions of VMware products), and for general
discussion about this program, go to
http://www.insanelymac.com/forum/index.php?showtopic=220750 .
